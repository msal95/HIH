import axios from 'axios';
import { useQuery, useQueryClient, useMutation} from 'react-query';
import laravelApi from './laravelApi';
import { integrationKey } from './queryKeys';

export function useGetIntegration(filters) {
    async function getData() {
        let data = null;
        await axios.get(laravelApi.integration.get, { params: filters }).then((result) => {
            data = result.data?.data;
        });
        return data;
    }

    return useQuery([integrationKey.integration, filters], getData, { staleTime: 0 });
}

export function useDeleteEventWithForm() {
    const queryClient = useQueryClient();
    return useMutation((id) => axios.delete(`${laravelApi?.integration?.delete}/${id}`, {}).then((result) => result.data), {
        onSuccess: () => {
            // Invalidate and refetch
            queryClient.invalidateQueries(integrationKey?.integration);
        },
    });
}

export function useIntegrationImport() {
    const queryClient = useQueryClient();

    return useMutation(
        (data) =>
            axios
                .post(laravelApi.integration.post, data, {
                    headers: {
                        'Content-Type': 'multipart/form-data',
                    },
                })
                .then((result) => result.data),
        {
            onSuccess: () => {
                // Additional logic to update the query
                queryClient.refetchQueries(integrationKey.integration);
            },
        }
    );
}

