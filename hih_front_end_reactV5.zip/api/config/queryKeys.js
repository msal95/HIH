export const testKey = {
    test: 'test',
};
export const integrationKey = {
    integration: 'integration',
};
export const formBuilderKey = {
    formBuilder: 'formBuilder',
};
export const getModelKey = {
    getModel: 'getModel',
};
export const userKey = {
    user: 'user',
};
