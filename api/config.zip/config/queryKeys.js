export const testKey = {
    test: 'test',
};
